from .client_list import client_id, clients_list
from .logger import geez_userbot_on
from .startup import geez_client, multigeez
